# 2026-10-14 배포 완료 업데이트 (이전 차단 기록보다 우선)

공개 주소: https://eodigaji-app-production.up.railway.app
Railway: 사용자 승인으로 작업공간 FREE / ACTIVE 전환 완료.
프로젝트 1개 제한 때문에 기존 mjc-ai-campus-agent-backend 프로젝트 안에 eodigaji-app 독립 서비스 추가. 기존 서비스 코드는 변경하지 않음.
서비스 ID: 230343bd-2813-4707-929c-f9ce11a17502
배포 ID: a1a403c0-76ca-45ff-abce-4f3b1cbb5654 (SUCCESS)
API 키는 사용자 승인으로 서비스 환경변수에 설정. GitHub/배포 소스에 .env 미포함.
검증: HTTPS health 200, ready=true, 실제 카카오 장소 12개, Gemini 실내/3만원/3시간 요청 결과 26,000원/150분.
공개 브라우저에서 지도 이미지 41/41 로드, 오류 없음. 카카오 도메인 설정을 추가로 변경하지 않음.
남은 검증: 사용자가 공개 주소에서 실제 로그인/저장/재로그인 및 휴대폰 홈 화면 설치 확인. 인증 메일 복귀 주소 설정 확인 필요.
무료 서비스는 미사용 시 잠들 수 있고 재시작/재배포 시 메모리 세션이 초기화됨.
GitHub 자동 배포 연결은 아직 설정하지 않았음. 현재는 Railway CLI 업로드 배포.
다음 배포는 railway up artifacts/deploy-railway --path-as-root --service eodigaji-app 사용 (먼저 패키지 최신화 필수).
USB와 APK는 이번에 갱신하지 않음.

---
# 2026-10-14 최신 작업 상태

- PWA 설치 manifest/PNG 아이콘/설치 안내/오프라인 안내 추가.
- 서비스 워커는 공개 offline.html만 캐시하며 계정·코스·API는 캐시하지 않음.
- 카카오 지도 이미지를 공통 사진 오류 처리에서 제외. 브라우저 이미지 34개 로드 확인.
- 취향 수정: 이름/성별/나이/성격/MBTI/관심사 6단계 슬라이드, 이전 입력 유지 및 저장 확인.
- 전체 테스트 38개 통과, npm run check와 npm run build:mobile 통과.
- railway.json 및 비밀 파일 없는 artifacts/deploy-railway 패키지 준비.
- 사용자 승인: Railway 무료 범위 배포 및 해당 서버의 비밀 환경변수로 기존 API 설정 복사.
- 배포 차단: Railway 프로젝트 생성 시 trial expired / select a plan 오류 반환.
- 현재 Railway 계정은 HOBBY / INACTIVE, trialDaysRemaining=0. 크레딧 표시와 별개로 생성 차단.
- 서버 생성/배포/환경변수 업로드 미실행. 공개 서비스 URL 없음. 유료 결제 미진행.
- 다음: 무료 배포 가능한 다른 서비스 계정을 준비하거나 사용자가 Railway 요금제를 결정한 뒤 재개.
- 공개 주소 확정 후 APP_ORIGIN, Kakao 웹 도메인, Supabase 복귀 주소 설정 및 실제 로그인/AI/지도 검증 필요.
- 로컬 서버는 npm start로 실행. API 키는 .env에만 있고 공개 Git에 포함하지 않음.
- 이번 변경은 USB에 복사하지 않았고 APK도 재빌드하지 않음.

---
어디가지 베타 — 2026-10-07 작업 인수인계
==================================================
저장소: https://github.com/hoo419/eodigaji-app (공개), 브랜치 master
버전: 0.2.0

이번 변경
- public/app.js: 로그아웃 시 과거 체험 프로필을 다시 표시하던 문제 수정.
- 로그아웃 API 실패 시 로그인 상태를 유지하고 오류 표시.
- 온라인 모드에서 새로고침 시 로컬 체험 프로필 대신 인증 계정 정보만 로드.
- 게스트 프로필이 있어도 로그인 진입 버튼 제공.
- tests/logout-ui.test.mjs: 위 문제에 대한 회귀 테스트 3개 추가.

검증 결과
- 2026-10-07 npm test: 34개 통과, npm run check 통과.
- 브라우저에서 로그아웃 상태의 이름·나이·취향 미표시 확인.
- 사용자가 재로그인 확인 완료라고 응답했고, 이후 로그인된 마이페이지 표시 확인.
- 실제 AI → 코스 생성 → 저장 → 재로그인 후 코스 유지 전체 검증은 미완료.
  AI 입력 화면까지만 열었으며 이번 작업에서 새 AI 요청이나 저장 테스트는 수행하지 않음.

다른 컴퓨터에서 이어가기
1. USB의 '앱 개발' 폴더를 PC 로컬 디스크로 복사합니다.
2. Node.js 22 이상 설치 후 해당 폴더에서 npm ci 를 실행합니다.
3. .env가 있는지 확인합니다. 비밀 키는 GitHub에 올리지 않습니다.
4. npm test / npm run check 로 확인하고 npm start 로 서버를 켭니다.
5. http://127.0.0.1:4173 에 접속하고 다시 로그인합니다.
   서버 세션은 메모리 기반이므로 컴퓨터 이동 또는 서버 재시작 시 재로그인이 필요합니다.
6. GitHub에서 이어받으면 git clone https://github.com/hoo419/eodigaji-app.git 실행 후
   USB 작업본의 .env를 복사합니다. GitHub에는 .env가 없습니다.

다음 작업
1. AI에 지역·예산·시간·실내외 조건을 입력해 실제 코스 결과 비교.
2. 코스 저장/삭제와 재로그인 후 유지 여부 확인 (실제 계정 로그인은 사용자가 입력).
3. 운영 서버 제공업체와 HTTPS 주소 결정 후 배포. 아직 운영 서버 배포 안 됨.
4. mobile/config.json apiBase에 HTTPS 서버 주소 설정 후 Android 재빌드 및 실기기 검증.

모바일 주의
- 현재 mobile/config.json의 apiBase는 비어 있으므로 모바일은 오프라인 샘플 모드입니다.
- 이번 로그인 수정은 소스에 반영했으며 APK는 이번에 재빌드하지 않았습니다.
- 기존 APK/ZIP은 이전 빌드입니다. 최신 수정 반영본으로 오해하지 마세요.
- Android 빌드는 JDK 21 / Android SDK가 필요합니다. npm run android:build 사용.
- node_modules, .tooling, 빌드 캐시 및 PC 전용 local.properties는 이전 대상에서 제외합니다.
- USB 기존 .git은 덮어쓰지 않습니다. USB의 소스가 최신이며 Git 이력은 GitHub clone으로 받으세요.

아래는 2026-09-30 이전 작업 기록이며 최신 상태는 위 내용을 우선합니다.
==================================================
